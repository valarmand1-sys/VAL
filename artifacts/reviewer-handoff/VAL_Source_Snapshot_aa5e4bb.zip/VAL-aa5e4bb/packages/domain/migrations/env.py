"""Alembic environment for Val's authoritative store.

No connection string is committed. The URL comes from `VAL_DATABASE_URL`, or the
local development default in `val_domain.database` — which addresses port 5433,
never 5432.
"""

from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from val_domain.database import database_url
from val_domain.schema import Base

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# A caller that has already named a database wins. Overriding it unconditionally
# would send a programmatic `command.upgrade` — the schema tests, for one — at
# whatever `VAL_DATABASE_URL` happened to hold, which is how a test suite
# migrates the authoritative store by accident.
if not config.get_main_option("sqlalchemy.url", None):
    config.set_main_option("sqlalchemy.url", database_url())

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Emit SQL to a script rather than a database."""
    context.configure(
        url=config.get_main_option("sqlalchemy.url"),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Apply migrations against a live connection."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
