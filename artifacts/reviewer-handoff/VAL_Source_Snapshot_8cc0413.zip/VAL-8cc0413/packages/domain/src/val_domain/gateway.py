"""The Model Gateway's typed contracts (`01-architecture.md` §5.1).

These are the shapes every component speaks — provider-neutral by construction.
Nothing here knows how any provider spells its request; that knowledge lives in
`val_providers`, and only there.
"""

from datetime import date
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class Classification(StrEnum):
    """Data classification (`01-architecture.md` §5.4). Ambiguity resolves upward."""

    PUBLIC = "public"
    INTERNAL = "internal"
    PROTECTED = "protected"
    RESTRICTED = "restricted"


class TaskType(StrEnum):
    """The Layer 0 task types of `04-layer-0.md` §2.2, exactly."""

    CONVERSATION = "conversation"
    CLASSIFICATION = "classification"
    STRIP = "strip"
    BLIND_POSITION = "blind_position"
    TITLE = "title"


class CallStatus(StrEnum):
    """`model_calls.status`, exactly."""

    OK = "ok"
    ERROR = "error"
    REFUSED = "refused"


class CostCertainty(StrEnum):
    """Whether this row's cost is a fact or an absence (`04-layer-0.md` §2.2).

    A provider attempt has exactly three accounting outcomes, and only two of
    them are rows:

    - **NOT_SENT** — no provider request occurred. Cost is definitively zero and
      this was not a model call, so **no row is written at all**. That is why
      there is no enum member for it: a row asserting a call that never happened
      is the error this distinction exists to prevent.
    - **SENT_COST_KNOWN** — `KNOWN`. The request occurred and the response or
      error carried reliable usage, so `tokens_in`, `tokens_out`, and `cost`
      hold real figures.
    - **SENT_COST_UNKNOWN** — `UNKNOWN`. The request occurred — or may have —
      and usage cannot be established from what came back. `tokens_in`,
      `tokens_out`, and `cost` are **NULL**, never zero. Zero is a claim, and it
      is the wrong one: a call that reached the provider consumed input tokens
      whatever the transport did afterwards.

    A NULL `cost_certainty` on a row means only that the row predates this
    distinction (17 August 2026). It is not a third state.
    """

    KNOWN = "known"
    UNKNOWN = "unknown"


class GatewayErrorKind(StrEnum):
    """The one normalized error contract (`01-architecture.md` §5.1).

    Provider timeouts, refusals, rate limits, invalid output, outages, and
    data-policy rejections all arrive as one of these, never as a provider's own
    exception type.
    """

    TIMEOUT = "timeout"
    REFUSAL = "refusal"
    RATE_LIMIT = "rate_limit"
    INVALID_REQUEST = "invalid_request"
    AUTHENTICATION = "authentication"
    PROVIDER_ERROR = "provider_error"
    INVALID_OUTPUT = "invalid_output"
    BUDGET_EXCEEDED = "budget_exceeded"
    NOT_ELIGIBLE = "not_eligible"
    RESTRICTED_CONTENT = "restricted_content"
    #: The router found no configuration that is admitted, eligible, ready, and
    #: affordable. Truthful unavailability — never a reason to downgrade the
    #: content's classification or to reach for an unadmitted route.
    NO_ELIGIBLE_ROUTE = "no_eligible_route"


class Admission(StrEnum):
    """How far a configuration has got through `01-architecture.md` §5.2.1.

    The vocabulary exists because the architecture's routing rule said *qualified*
    while §5.2.1 said qualification cannot exist before the Layers 2-3 exam suite.
    Both are now true of different states, and Layer 0 asserts only the weaker one.

    `QUALIFIED` is reserved. Nothing may carry it until an exam record exists,
    and no code path sets it — a configuration is promoted to it by a recorded
    decision, never by an implementation that finds the word convenient.
    """

    #: Present in the registry but not permitted to carry traffic.
    NOT_ADMITTED = "not_admitted"
    #: Admitted for Layer 0 use on the strength of the eligibility ruling and a
    #: working adapter. This is the strongest state any Layer 0 route may hold.
    PROVISIONALLY_ADMITTED = "provisionally_admitted"
    #: Passed the system-specific exam suite. No such record exists yet.
    QUALIFIED = "qualified"


class AdapterStatus(StrEnum):
    """Whether code exists that speaks this provider's dialect (§5.2.1).

    Separate from admission on purpose: an implemented adapter is not a live
    provider, and neither is evidence of eligibility.
    """

    IMPLEMENTED = "implemented"
    NOT_IMPLEMENTED = "not_implemented"


class PricingFeature(StrEnum):
    """Whether caching or batch pricing applies to a configuration (§5.2).

    `NOT_VERIFIED` is the honest default and is not a synonym for absent: it
    records that the provider's own pricing page has not been read for this, in
    the same spirit as `rates_verified_on`. Layer 0 uses neither caching nor
    batch pricing (`01-architecture.md` §5.3 makes them first-class from the
    layer that has repetitive context to cache), so nothing here is load-bearing
    yet — but a guessed value would become load-bearing the moment it is.
    """

    NOT_VERIFIED = "not_verified"
    AVAILABLE = "available"
    NOT_AVAILABLE = "not_available"
    NOT_APPLICABLE = "not_applicable"


class ReasoningEffort(StrEnum):
    """The configuration's reasoning setting, or a typed absence (§5.2).

    `NOT_APPLICABLE` means the provider has no such concept for this model. It
    is a recorded fact, not a missing value, and it is why this is an enum rather
    than an optional string that would leave "unset" and "unsupported"
    indistinguishable.
    """

    NOT_APPLICABLE = "not_applicable"
    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class GatewayError(Exception):
    """A failed gateway call, in normalized form."""

    def __init__(self, kind: GatewayErrorKind, detail: str) -> None:
        super().__init__(f"{kind.value}: {detail}")
        self.kind = kind
        self.detail = detail


class ModelConfig(BaseModel):
    """One entry of the Model Configuration Registry (`01-architecture.md` §5.2).

    A versioned record, not a model name in a settings file. `id` is the stable
    key `model_calls.model_config_id` refers to; `slug` is the stable
    human-readable name every cost view displays. Costs are per million tokens,
    as published by the provider, and are the rates `model_calls.cost` is
    computed from at call time — never recomputed later.
    """

    model_config = ConfigDict(frozen=True)

    id: UUID
    slug: str = Field(pattern=r"^[a-z0-9]+(-[a-z0-9]+)*$")
    provider: str
    model_identifier: str
    display_name: str
    context_window_tokens: int = Field(gt=0)
    max_output_tokens: int = Field(gt=0)
    #: Reasoning or sampling settings (§5.2). `temperature = None` means the
    #: configuration sets none and the provider's own default stands — recorded
    #: rather than filled in with an invented number.
    reasoning_effort: ReasoningEffort
    temperature: float | None = None
    cost_per_mtok_in_usd: float = Field(gt=0)
    cost_per_mtok_out_usd: float = Field(gt=0)
    #: Whether caching or batch pricing applies (§5.2). See `PricingFeature`:
    #: `NOT_VERIFIED` records that this has not been read from the provider.
    caching: PricingFeature = PricingFeature.NOT_VERIFIED
    batch_pricing: PricingFeature = PricingFeature.NOT_VERIFIED
    eligible_classifications: frozenset[Classification]
    #: Weaknesses observed in this house's own use (§5.2). Written from
    #: observation, never from a provider's or a benchmark's claims, so an empty
    #: tuple means "none observed here yet" rather than "none exist".
    known_weaknesses: tuple[str, ...] = ()
    #: The preferred successor when this route cannot answer, or None for an
    #: explicit NONE. A fallback is re-checked against every admission and
    #: eligibility rule when it is reached; it never inherits the failed route's
    #: standing (`01-architecture.md` §5.4).
    fallback_slug: str | None
    #: How far this configuration has got through §5.2.1, and whether code exists
    #: that speaks its dialect. Independent: neither implies the other, and
    #: neither implies eligibility.
    admission: Admission
    adapter_status: AdapterStatus
    #: When this configuration became routable, and when it stopped being so.
    activated_on: date
    retired_on: date | None = None
    #: The day the rates above were read from the provider's own documentation.
    #: Rates go stale silently, and a stale rate makes cost attribution quietly
    #: wrong rather than visibly wrong — so the date is carried per entry and
    #: surfaced as a startup warning once it ages (`registry.stale_rates`).
    rates_verified_on: date
    #: The day this exact route last answered a real call successfully, or None
    #: if it never has. An implemented adapter is not a live provider
    #: (`01-architecture.md` §5.2.1): only a real answer proves the route works.
    #: Set from an observed `model_calls` row, never from the fact code exists.
    last_live_call_on: date | None = None
    #: Google-only structural requirement (`01-architecture.md` §5.4 amendment):
    #: True only when startup has verified the key is attached to paid billing.
    #: Configuration cannot claim it; the verifier sets it.
    billing_verified: bool = False
    retired: bool = False


class Message(BaseModel):
    """One conversational turn, provider-neutral."""

    model_config = ConfigDict(frozen=True)

    role: str = Field(pattern=r"^(user|assistant)$")
    content: str


class GatewayRequest(BaseModel):
    """What a caller asks of the gateway.

    The caller states the classification; the gateway never infers it
    (`01-architecture.md` §5.4 — classification is computed before routing,
    never by the model that will receive the content). Attribution fields
    mirror `model_calls` and are recorded on every call.
    """

    model_config = ConfigDict(frozen=True)

    task_type: TaskType
    classification: Classification
    messages: tuple[Message, ...]
    system: str | None = None
    max_output_tokens: int = Field(default=4096, gt=0)
    project_id: UUID | None = None
    conversation_id: UUID | None = None
    message_id: UUID | None = None
    #: Which persona revision was assembled into this request's context (WP-0.5).
    #: Attribution, exactly like the three fields above it — set by context
    #: assembly, recorded by the gateway, never chosen by a provider. None on the
    #: paths that legitimately assemble no persona, which are not Val utterances.
    persona_id: UUID | None = None


class GatewayResponse(BaseModel):
    """What the gateway returns, with the cost already attributed and recorded."""

    model_config = ConfigDict(frozen=True)

    text: str
    model_config_id: UUID
    slug: str
    provider: str
    model_identifier: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    latency_ms: int
    provider_request_id: str | None
